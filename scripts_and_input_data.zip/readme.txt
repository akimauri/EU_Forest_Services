To run the scripts from terminal in multiple cores in tiles:

	for i in $(seq 25); do    echo $i;    python2 script_multi.py rcp85 & done

to run the single scripts:

	python2 script_single.py rcp85



To use the scripts in Spyder, the rcp variables need to be defined within the script.
